var searchData=
[
  ['clearscreen',['ClearScreen',['../gridmanagement_8cpp.html#a6a3ca153f0817e8ba91a023b886bb662',1,'ClearScreen():&#160;gridmanagement.cpp'],['../gridmanagement_8h.html#a6a3ca153f0817e8ba91a023b886bb662',1,'ClearScreen():&#160;gridmanagement.cpp']]],
  ['color',['Color',['../gridmanagement_8cpp.html#ac9357ee33d7442ff035f7a0c2b61cce6',1,'Color(const string &amp;Col):&#160;gridmanagement.cpp'],['../gridmanagement_8h.html#a7f0df05a97c053bfa8a3e5863b0a0e80',1,'Color(const std::string &amp;Col):&#160;gridmanagement.h']]]
];
