#include <iostream>
#include <iomanip>
#include <fstream>
#include "gridmanagement.h"

#include "type.h" //nos types
#include "params.h" //nos parametres

using namespace std;



void ClearScreen()
{
    cout << "\033[H\033[2J";
}// ClearScreen ()

void Color (const string & Col)
{
    cout << "\033[" << Col.c_str () <<"m";
} // Color ()


void DisplayGrid (const CMat & Mat, const CMyParam & Param, const unsigned & Loop, const unsigned & Points)
{
    ClearScreen ();
    Color (KColor.find("KReset")->second);
    const unsigned KNbLine = Mat.size ();

    cout << "Tours : #" << Loop << " | Points : " << Points << endl << endl;

    for (unsigned i (0); i < KNbLine; ++i)
    {
        for (unsigned j (0); j < Mat[i].size(); ++j)
        {
            if (Param.MapParamChar.find("TokenP1")->second ==  Mat[i][j])
                Color (Param.MapParamString.find("ColorP1")->second );
            else
               Color (KColor.find("KReset")->second);
            cout << Mat[i][j];
            Color (KColor.find("KReset")->second);

        }
        cout << endl;
    }

}// DisplayGrid ()

bool InitGrid (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer, const std::string & Map)
{
    ifstream ifs (Map);
    if(!ifs.is_open())
        return false;

    string line;
    unsigned i(0);

    Mat.resize (Params.MapParamUnsigned.find("NbColumn")->second);
    const CVLine KLine (Params.MapParamUnsigned.find("NbRow")->second, KEmpty);
    for (CVLine &ALine : Mat)
        ALine = KLine;

    while (getline (ifs, line))
    {
        for(unsigned j(0); j < line.size(); ++j){
            if(line[j] == ' ')
                Mat[i][j] = '*';
            else
                Mat[i][j] = line[j];

            if(Mat[i][j] == 'x'){
                Mat[i][j] = Params.MapParamChar.find("TokenP1")->second;
                PosPlayer.first = i;
                PosPlayer.second = j;
            }

        }
        ++i;
    }

    return true;
} // InitGrid ()
