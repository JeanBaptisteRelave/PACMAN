#include <iostream>
#include <unistd.h>
#include <termios.h>

#include "game.h"
#include "params.h"
#include "gridmanagement.h"

#include <map>
using namespace std;
template <class T, class U>
void ShowMap (const map<T,U> & AMap){
    for (const pair <T,U> & Val : AMap)                cout << "Cle : " << Val.first << "   "             << "Valeur : " << Val.second << endl;
    cout << endl;
}// ShowMap ()

struct termios saved_attributes;

void reset_input_mode (void)
{
  tcsetattr (STDIN_FILENO, TCSANOW, &saved_attributes);
}

void set_input_mode (void)
{
  struct termios tattr;

  /* Make sure stdin is a terminal. */
  if (!isatty (STDIN_FILENO))
    {
      fprintf (stderr, "Not a terminal.\n");
      exit (EXIT_FAILURE);
    }

  /* Save the terminal attributes so we can restore them later. */
  tcgetattr (STDIN_FILENO, &saved_attributes);
  atexit (reset_input_mode);

  /* Set the funny terminal modes. */
  tcgetattr (STDIN_FILENO, &tattr);
  tattr.c_lflag &= ~(ICANON|ECHO); /* Clear ICANON and ECHO. */
  tattr.c_cc[VMIN] = 1;
  tattr.c_cc[VTIME] = 0;
  tcsetattr (STDIN_FILENO, TCSAFLUSH, &tattr);
}

unsigned MoveToken (CMat & Mat, const char & Move, CPosition & Pos, unsigned & Points)
{   
    char car = Mat [Pos.first][Pos.second];
    Mat [Pos.first][Pos.second] = KEmpty;
    switch (Move)
    {
    case 'Z':
        if(Mat[Pos.first - 1][Pos.second] == '-' || Mat[Pos.first - 1][Pos.second] == '|')
        {
            Mat [Pos.first][Pos.second] = car;
            return 0;
            break;
        }
        if(Mat[Pos.first - 1][Pos.second] == '*')
            ++Points;
        --Pos.first;
        break;
    case 'Q':
        if(Mat[Pos.first][Pos.second - 1] == '-' || Mat[Pos.first][Pos.second - 1] == '|')
        {
            Mat [Pos.first][Pos.second] = car;
            return 0;
            break;
        }
        else if(Mat[Pos.first][Pos.second - 1] == '*')
            ++Points;
        --Pos.second;
        break;
    case 'D':
        if(Mat[Pos.first][Pos.second + 1] == '-' || Mat[Pos.first][Pos.second + 1] == '|')
        {
            Mat [Pos.first][Pos.second] = car;
            return 0;
            break;
        }
        else if(Mat[Pos.first][Pos.second + 1] == '*')
            ++Points;
        ++Pos.second;
        break;
    case 'S':
        if(Mat[Pos.first + 1][Pos.second] == '-' || Mat[Pos.first + 1][Pos.second] == '|')
        {
            Mat [Pos.first][Pos.second] = car;
            return 0;
            break;
        }
        else if(Mat[Pos.first + 1][Pos.second] == '*')
            ++Points;
        ++Pos.first;
        break;
    }
    Mat [Pos.first][Pos.second] = car;

    return 1;
} //MoveToken ()


int ppal (void)
{
    unsigned PartyNum (1);
    unsigned Points(0);

    CMat Mat;
    string Map ("../PacMan/Nos_fichiers/maps/map1.txt");

    char Move;

    bool Victory (false);

    CPosition PosPlayer;

    CMyParam Param;
    int RetVal = LoadParams(Param, "../PacMan/Nos_fichiers/config.yaml");
    if (RetVal != 0)
    {
        return RetVal;
    }

    if (!InitGrid(Mat, Param, PosPlayer, Map))
    {
       cout << "Impossible de trouver la map...";
       return 0;
    }

    DisplayGrid (Mat, Param, PartyNum, Points);

    while (! Victory)
    {
        set_input_mode ();

        read (STDIN_FILENO, &Move, 1); //Lire lettre entré

        Move = toupper (Move);

        while(MoveToken (Mat, Move, PosPlayer, Points))

        ClearScreen();
        DisplayGrid (Mat, Param, PartyNum, Points);

        //Increase party's number
        ++PartyNum;
    }//while (no victory)

    if (!Victory)
    {
        Color (KColor.find("KMAgenta")->second);
        cout << "Aucun vainqueur" << endl;
        return 1;
    }

    Color (KColor.find("KGreen")->second);
    cout << "Félicitations Joueur vous avez gagné :)" << endl;
    Color (KColor.find("KReset")->second);
    return 0;
} //ppal ()
