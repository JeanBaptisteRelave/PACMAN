#ifndef GRIDMANAGEMENT_H
#define GRIDMANAGEMENT_H

/*!
 * \file gridmanagement.h
 * \brief Set of usefull functions for the grid management
 * \author Alain Casali
 * \author Marc Laporte
 * \version 1.0
 * \date 18 décembre 2018
 */

#include <string>

#include "type.h" //nos types

/**
 * @brief Clear the current terminal
 * @fn void ClearScreen ();
 */
void ClearScreen ();

/**
 * @brief Set the color of the future input in the terminal
 * @param[in] Col : Next color to be used
 * @fn void Color (const std::string & Col);
 */
void Color (const std::string & Col);


/**
 * @brief Display the grid according to the parameters
 * @param[in] Mat : Game grid
 * @param[in] Params : List of usefull parameters
 * @param[in] Loops : Gameloops Number
 * @param[in] Points : Player's points
 * @fn void DisplayGrid (const CMat & Mat, const CMyParam & Params, bool ShowLineNumber = true, bool ShowColor = true, const unsigned & Tours);
 */
void DisplayGrid (const CMat & Mat, const CMyParam & Params, const unsigned & Loops, const unsigned & Points);


/*!
 * \brief Initialization of the Matrix from scratch
 * \param[out] Mat the matrix to be initialized
 * \param[in] Parms Set of game's parameters
 * \param[out] PosPlayer position
 * @fn void InitGrid (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer, const std::string & Map);
 */
bool InitGrid (CMat & Mat, const CMyParam & Params, CPosition & PosPlayer, const std::string & Map);

#endif // GRIDMANAGEMENT_H
